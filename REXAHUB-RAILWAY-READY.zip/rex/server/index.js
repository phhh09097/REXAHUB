import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import pg from "pg";

const { Pool } = pg;
const app = express();
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const clientPath = path.join(__dirname, "..", "dist");

let pool = null;
if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes("railway") ? { rejectUnauthorized: false } : undefined
  });
}

app.get("/api/health", async (_req, res) => {
  let database = "not-configured";
  if (pool) {
    try { await pool.query("SELECT 1"); database = "ok"; }
    catch { database = "error"; }
  }
  res.json({ ok: true, database, service: "REXAHUB" });
});

app.get("/api/stats", (_req, res) => {
  res.json({
    users: 1284,
    active: 917,
    servers: 8,
    traffic: "4.82 TB"
  });
});

app.use(express.static(clientPath));
app.get("/{*splat}", (_req, res) => res.sendFile(path.join(clientPath, "index.html")));

const port = process.env.PORT || 3000;
app.listen(port, "0.0.0.0", () => {
  console.log(`REXAHUB listening on ${port}`);
});