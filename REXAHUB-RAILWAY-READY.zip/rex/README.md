# REXAHUB

Glassmorphism VPN control-panel starter built with React + Vite + Node.js/Express.

## Run locally

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm start
```

## GitHub

Create a GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial REXAHUB panel"
git branch -M main
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

## Railway

1. Create a new Railway project.
2. Deploy from the GitHub repository.
3. Railway runs `npm run build`, then `npm start`.
4. `PORT` is read automatically from Railway.
5. If PostgreSQL is added, set/use the provided `DATABASE_URL`.

The included `/api/health` endpoint can be used to verify the deployment.
