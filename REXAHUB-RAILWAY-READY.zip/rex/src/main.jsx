import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const menu = [
  ["◈", "داشبورد"],
  ["♙", "کاربران"],
  ["⌁", "کانفیگ‌ها"],
  ["◉", "سرورها"],
  ["◫", "اشتراک‌ها"],
  ["◌", "ترافیک"],
  ["⚙", "تنظیمات"]
];

function App() {
  const [active, setActive] = useState("داشبورد");
  const [stats, setStats] = useState({ users: 0, active: 0, servers: 0, traffic: "0 TB" });

  useEffect(() => {
    fetch("/api/stats").then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const cards = [
    ["کاربران", stats.users.toLocaleString("fa-IR"), "+12.8%", "♙"],
    ["کاربران فعال", stats.active.toLocaleString("fa-IR"), "+8.4%", "◉"],
    ["سرورهای آنلاین", stats.servers.toLocaleString("fa-IR"), "پایدار", "⌁"],
    ["مصرف ترافیک", stats.traffic, "+18.2%", "◫"]
  ];

  return (
    <div className="app">
      <div className="orb orb1" /><div className="orb orb2" />
      <aside className="sidebar glass">
        <div className="brand"><div className="logo">R</div><div><b>REXA<span>HUB</span></b><small>VPN CONTROL CENTER</small></div></div>
        <div className="profile glass2"><div className="avatar">A</div><div><b>Admin</b><small>مدیر سیستم</small></div><i>●</i></div>
        <nav>{menu.map(([icon, label]) =>
          <button className={active === label ? "nav active" : "nav"} onClick={() => setActive(label)} key={label}>
            <span>{icon}</span>{label}{active === label && <em>›</em>}
          </button>
        )}</nav>
        <div className="sideBottom"><div className="statusDot"></div><div><b>وضعیت سیستم</b><small>همه سرویس‌ها آنلاین</small></div></div>
      </aside>

      <main>
        <header>
          <div><span className="eyebrow">CONTROL CENTER</span><h1>{active}</h1></div>
          <div className="actions"><button className="iconBtn glass">⌕</button><button className="iconBtn glass">♢</button><div className="date glass">۲۴ سپتامبر ۲۰۲۶</div></div>
        </header>

        <section className="hero glass">
          <div><span className="pill">● سیستم آنلاین</span><h2>خوش آمدی، Admin 👋</h2><p>همه‌چیز تحت کنترل شماست. وضعیت شبکه را از اینجا مدیریت کنید.</p></div>
          <div className="heroArt"><div className="ring r1"></div><div className="ring r2"></div><div className="core">R</div></div>
        </section>

        <section className="cards">{cards.map(([title, value, change, icon]) =>
          <div className="stat glass" key={title}><div className="statTop"><span>{title}</span><div className="miniIcon">{icon}</div></div><strong>{value}</strong><small className={change.includes("+") ? "up" : ""}>{change}</small></div>
        )}</section>

        <section className="grid">
          <div className="panel glass">
            <div className="panelHead"><div><h3>مصرف ترافیک</h3><small>۷ روز اخیر</small></div><button className="select">این هفته⌄</button></div>
            <div className="chart"><div className="gridline g1"></div><div className="gridline g2"></div><div className="gridline g3"></div><svg viewBox="0 0 700 220" preserveAspectRatio="none"><defs><linearGradient id="fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#6d7cff" stopOpacity=".35"/><stop offset="100%" stopColor="#6d7cff" stopOpacity="0"/></linearGradient></defs><path d="M0,170 C70,155 70,95 140,120 S230,175 300,130 S390,50 455,95 S520,145 585,80 S640,45 700,65 L700,220 L0,220Z" fill="url(#fill)"/><path d="M0,170 C70,155 70,95 140,120 S230,175 300,130 S390,50 455,95 S520,145 585,80 S640,45 700,65" fill="none" stroke="#8190ff" strokeWidth="4" strokeLinecap="round"/></svg><div className="labels"><span>شنبه</span><span>یکشنبه</span><span>دوشنبه</span><span>سه‌شنبه</span><span>چهارشنبه</span><span>پنجشنبه</span><span>جمعه</span></div></div>
          </div>

          <div className="panel glass">
            <div className="panelHead"><div><h3>وضعیت سرورها</h3><small>Real-time</small></div><span className="online">● آنلاین</span></div>
            <div className="servers">
              {["DE • Frankfurt", "TR • Istanbul", "NL • Amsterdam", "US • New York"].map((s, i) =>
                <div className="server" key={s}><div className="serverIcon">⌁</div><div className="serverName"><b>{s}</b><small>Ping {38+i*11}ms</small></div><div className="load"><span style={{width: `${42+i*9}%`}}></span></div><strong>{42+i*9}%</strong></div>
              )}
            </div>
          </div>
        </section>

        <section className="quick glass">
          <div><h3>عملیات سریع</h3><small>دسترسی سریع به ابزارهای مدیریت</small></div>
          <div className="quickBtns"><button>＋ افزودن کاربر</button><button>＋ ساخت کانفیگ</button><button>⌁ افزودن سرور</button></div>
        </section>
        <footer>REXAHUB • VPN CONTROL CENTER <span>v1.0.0</span></footer>
      </main>
    </div>
  );
}
createRoot(document.getElementById("root")).render(<App />);